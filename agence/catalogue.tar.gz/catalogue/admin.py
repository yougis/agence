from django.contrib import admin
from catalogue.models import Company, Scene, SceneCat, Age, Duration, Partnership

admin.site.register(Company)
admin.site.register(Scene)
admin.site.register(SceneCat)
admin.site.register(Age)
admin.site.register(Duration)
admin.site.register(Partnership)
